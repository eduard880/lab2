from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """
    Модель пользователя с расширенными полями и ролями
    """

    class Role(models.TextChoices):
        USER = 'user', 'Обычный пользователь'
        ADMIN = 'admin', 'Администратор'

    role = models.CharField(
        max_length=10,
        choices=Role.choices,
        default=Role.USER,
        verbose_name='Роль'
    )

    def is_admin(self):
        return self.role == self.Role.ADMIN

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'

class Book(models.Model):
    """
    Модель книги для магазина
    """
    title = models.CharField(
        max_length=200,
        verbose_name='Название'
    )
    author = models.CharField(
        max_length=100,
        verbose_name='Автор'
    )
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name='Цена'
    )
    description = models.TextField(
        blank=True,
        verbose_name='Описание'
    )
    publication_date = models.DateField(
        null=True,
        blank=True,
        verbose_name='Дата публикации'
    )
    isbn = models.CharField(
        max_length=20,
        blank=True,
        verbose_name='ISBN'
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='Дата создания'
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='Дата обновления'
    )

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Книга'
        verbose_name_plural = 'Книги'
        ordering = ['-created_at']
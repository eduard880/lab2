from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import Book, User
from .forms import BookForm, RegisterForm, LoginForm
from django.contrib.auth import login, logout, authenticate

def book_list(request):
    """
    Отображение списка всех книг
    Доступно всем пользователям (включая неавторизованных)
    """
    books = Book.objects.all().order_by('-created_at')
    return render(request, 'books/book_list.html', {
        'books': books,
        'user': request.user
    })

def register_view(request):
    """
    Регистрация нового пользователя
    """
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('book_list')
    else:
        form = RegisterForm()
    return render(request, 'books/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('book_list')
            else:
                form.add_error(None, "Неверный логин или пароль")
    else:
        form = LoginForm()
    return render(request, 'books/login.html', {'form': form})

def logout_view(request):
    """
    Выход из системы
    """
    logout(request)
    return redirect('book_list')

# Декоратор для проверки административных прав
def admin_required(view_func):
    """
    Декоратор для проверки, что пользователь является администратором
    """
    return user_passes_test(
        lambda u: u.is_authenticated and u.is_admin(),
        login_url='book_list'
    )(view_func)

@login_required(login_url='login')
def add_book(request):
    """
    Добавление новой книги (доступно авторизованным пользователям)
    """
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm()
    return render(request, 'books/book_form.html', {
        'form': form,
        'title': 'Добавить книгу'
    })

@admin_required
def edit_book(request, pk):
    """
    Редактирование книги (доступно только администраторам)
    """
    book = get_object_or_404(Book, pk=pk)
    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm(instance=book)
    return render(request, 'books/book_form.html', {
        'form': form,
        'title': 'Редактировать книгу'
    })

@admin_required
def delete_book(request, pk):
    """
    Удаление книги (доступно только администраторам)
    """
    book = get_object_or_404(Book, pk=pk)
    if request.method == 'POST':
        book.delete()
        return redirect('book_list')
    return render(request, 'books/book_confirm_delete.html', {'book': book})